import io
import json
import logging
import os
import sys
import traceback

from dataclasses import dataclass, field
from typing import List

# os.environ["OCI_PYTHON_SDK_NO_SERVICE_IMPORTS"] = "1" #to reduce OCI module import time
import oci
from fdk import response


try:
    DNS_ZONE_OCID = os.environ.get("DNS_ZONE_OCID")
    DNS_VNIC_ADDR_MODE = os.environ.get("DNS_VNIC_ADDR_MODE", "1") 
    #DNS_VNIC_ADDR_MODEs
    # 1. private IP addresses are considered for DNS records
    # 2. public IP addresses are considered for DNS records
except:
    logging.getLogger().error(f'One of mandatory environment variables is not set. [DNS_ZONE_OCID]')
    sys.exit(1)

# Dataclasses required to store instance attributes during application execution
@dataclass(init=True, repr=True)
class Instance:
    instance_id: str
    request_attributes: dict
    attributes: oci.core.models.instance.Instance = None
    vnics: List = field(default_factory=lambda: [])

@dataclass
class Vnic:
    vnic_id: str
    instance_id: str
    ip_addr: str
    hostname: str
    subnet_domain: str
    changed_hostname: bool = False
    record_hash: str = ""


def get_instance_network_details(instance):
    '''
    This function expects and Instance dataclass as parameter.
    It will use the instance_id attribute to get attached VNICs parameters:

    '''
    signer = oci.auth.signers.get_resource_principals_signer()
    # signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
    logging.getLogger().info(f'Getting network parameters of the instance {instance.instance_id}')

    try:
        ## Getting instance attributes

        logging.getLogger().debug(f'Getting instance {instance.instance_id} attributes')

        core_client = oci.core.ComputeClient({}, signer=signer)
        get_instance_response = core_client.get_instance(
            instance_id=instance.instance_id)
        
        if get_instance_response.status == 200 and get_instance_response.data :
            instance.attributes = get_instance_response.data
            logging.getLogger().debug(f'Instance attributes: {instance.attributes}')
        else:
            raise ValueError(f'Unexpected response or response data is empty when attempting to execute get_instance(instance_id={instance.instance_id})')

        ## Getting VNIC attachments

        if not hasattr(instance.attributes, "compartment_id"):
            raise ValueError("Missing instance_id attribute from the instance_attributes")
        
        list_vnic_attachments_response = core_client.list_vnic_attachments(compartment_id=instance.attributes.compartment_id, instance_id=instance.instance_id)

        if list_vnic_attachments_response.status == 200 and list_vnic_attachments_response.data :
            instance_vnic_attachments = list_vnic_attachments_response.data
            logging.getLogger().debug(f'Instance vnic attachments: {instance_vnic_attachments}')
        else:
            raise ValueError(f'Unexpected response or response data is empty when attempting to execute \
                list_vnic_attachments(compartment_id={instance.attributes.compartment_id}, instance_id={instance.instance_id})')

        logging.getLogger().debug(f'Instance {instance.instance_id} attached VNICs: {instance_vnic_attachments}')

        ## Getting VNIC attributes

        if len(instance_vnic_attachments):
            vcn_client = oci.core.VirtualNetworkClient({}, signer=signer)
            for vnic_attachment in instance_vnic_attachments:
                if vnic_attachment.lifecycle_state == "ATTACHED":
                    logging.getLogger().debug(f'Getting info of VNIC: {vnic_attachment.vnic_id}')

                    get_vnic_response = vcn_client.get_vnic(
                        vnic_id=vnic_attachment.vnic_id)

                    logging.getLogger().debug(f'VNIC info: {get_vnic_response.data}')
                    
                    hostname_label = get_vnic_response.data.hostname_label
                    private_ip = get_vnic_response.data.private_ip
                    public_ip = get_vnic_response.data.public_ip
                    
                    logging.getLogger().debug(f'Getting info of subnet {vnic_attachment.subnet_id}')

                    get_subnet_response = vcn_client.get_subnet(
                        subnet_id=vnic_attachment.subnet_id
                    )
                    subnet_domain_name = get_subnet_response.data.subnet_domain_name

                    if DNS_VNIC_ADDR_MODE == "1":
                        ip_addr = private_ip
                    else:
                        ip_addr = public_ip

                    if ip_addr:
                        new_vnic = Vnic(vnic_attachment.vnic_id, instance.instance_id, ip_addr, hostname_label, subnet_domain_name)
                        instance.vnics.append(new_vnic)

        logging.getLogger().debug(f'Found {len(instance.vnics)} VNICs for instance with id {instance.instance_id}')
        return True

    except Exception as e:
        logging.getLogger().error(traceback.format_exc())
        raise e


def handler(ctx, data: io.BytesIO = None):

    ## Parse body and extract instance ID
    instances = []
    try:
        body = json.loads(data.getvalue())
        logging.getLogger().debug(f'Body: {body}')

        if isinstance(body, list):
            for entry in body:
                instance_id = entry.get("data", {}).get("resourceId", "")
                if instance_id:
                    instances.append(Instance(instance_id, entry.get("data")))
            logging.getLogger().debug(f"Extracted instance ids from list data: {[entry.instance_id for entry in instances]}")
        
        elif isinstance(body, dict):
            instance_id = body.get("data", {}).get("resourceId", "")
            if instance_id:
                instances.append(Instance(instance_id, body.get("data")))
            logging.getLogger().debug(f"Extracted instance id from dict data: {[entry.instance_id for entry in instances]}")
        
        else:
            logging.getLogger().error(f"Unexpected body received: {body}") 
            return response.Response(
                ctx, 
                response_data=json.dumps(
                    {"message": f"Invalid body {body}"}),
                headers={"Content-Type": "application/json"},
                status_code=400
            )


    except Exception as e:
        logging.getLogger().error(f'error parsing json payload: {traceback.format_exc()}')
        sys.exit(1)


    if not instances:
        logging.getLogger().error(f'No instance_id attribute in received data: {data.getvalue()}')
        return response.Response(
                ctx, 
                response_data=json.dumps(
                    {"message": f"No instance id could be found"}
                ),
                headers={"Content-Type": "application/json"},
                status_code=400
        )
    
    ## Getting instance FQDNs
    try:
        for instance in instances:
            get_instance_network_details(instance)

    except Exception as e:
        logging.getLogger().error(f'error parsing json payload: {traceback.format_exc()}')
        return response.Response(
            ctx, 
            response_data=json.dumps(
                {"message": "Could not process data. Check logs for more details"}),
            headers={"Content-Type": "application/json"},
            status_code=409
        )

    signer = oci.auth.signers.get_resource_principals_signer()
    ## Getting domain of the DNS zone
    try:
        dns_client = oci.dns.DnsClient({}, signer=signer)
        get_zone_response = dns_client.get_zone(
            zone_name_or_id=DNS_ZONE_OCID)
        logging.getLogger().debug(f'get_zone_response status_code: {get_zone_response.status}')
        logging.getLogger().debug(f'get_zone_response data: {get_zone_response.data}')
        domain = get_zone_response.data.name
        logging.getLogger().info(f'DNS zone domain: {domain}')
    except Exception as e:
        logging.getLogger().error(f'Could not get the domain of DNS zone: {traceback.format_exc()}')
        return response.Response(
            ctx, 
            response_data=json.dumps(
                {"message": "Could not get the domain of DNS zone. Check logs for more details"}),
            headers={"Content-Type": "application/json"},
            status_code=409
        )
    
    ## Getting current records in the DNS zone
    try:
        get_zone_records_response = dns_client.get_zone_records(
            zone_name_or_id=DNS_ZONE_OCID)
        logging.getLogger().debug(f'get_zone_records_response status_code: {get_zone_records_response.status}')
        # logging.getLogger().debug(f'get_zone_records_response data: {get_zone_records_response.data}')
        current_dns_records = get_zone_records_response.data.items
        logging.getLogger().info(f'Current number of records in DNS zone: {len(current_dns_records)}')
    except Exception as e:
        logging.getLogger().error(f'could not get the DNS zone records: {traceback.format_exc()}')
        return response.Response(
            ctx, 
            response_data=json.dumps(
                {"message": "Could not get the DNS zone records. Check logs for more details"}),
            headers={"Content-Type": "application/json"},
            status_code=409
        )

    ## Generate instances records
    for instance in instances:
        ## Check if hostname is not already present in DNS Zone.
        ## If present, attempt to find alternative hostname using up to last 5 characters from instance ID
        ## if not present, preserve hostname
        map_of_duplicate_hostnames_to_unique_hostnames = {}
        for instance_hostname in set([ vnic.hostname for vnic in instance.vnics ]):
            if f'{instance_hostname}.{domain}' in [ entry.domain for entry in current_dns_records]:
                ## Instance's hostname is already present in DNS Zone, trying to generate new hostname.
                attempts = 5
                attempt = 1
                while attempt <= attempts:
                    logging.getLogger().debug(f'Found duplicate entry of {instance_hostname}. Attempting to try with new hostname: {instance_hostname}-{instance.instance_id[-attempt:]}')
                    new_hostname = f'{instance_hostname}-{instance.instance_id[-attempt:]}'
                    if f'{new_hostname}.{domain}' not in [ entry.domain for entry in current_dns_records]:
                        # Unique entry found. Update hostname mapping with new_hostname
                        map_of_duplicate_hostnames_to_unique_hostnames[instance_hostname] = new_hostname
                        break
                    else:
                        # Existing entry for this hostname, try adding a new character from instance_id
                        attempt += 1
                else:
                    # No unique entry found, assign empty string
                    map_of_duplicate_hostnames_to_unique_hostnames[instance_hostname] = ""
                    
            else:
                map_of_duplicate_hostnames_to_unique_hostnames[instance_hostname] = instance_hostname
        
        # Update hostname entries
        for old_hostname, new_hostname in map_of_duplicate_hostnames_to_unique_hostnames.items():
            if old_hostname != new_hostname:
                for vnic in instance.vnics:
                    if vnic.hostname == old_hostname:
                        vnic.hostname = new_hostname
                        vnic.changed_hostname = True

        # Add entries to DNS Zone
        try:
            items = []
            for vnic in instance.vnics:
                items.append(oci.dns.models.RecordOperation(
                    domain=f'{vnic.hostname}.{domain}',
                    rdata=vnic.ip_addr,
                    rtype="A",
                    ttl=30,
                    operation="ADD"
                ))
            
            patch_zone_records_response = dns_client.patch_zone_records(
                zone_name_or_id=DNS_ZONE_OCID,
                patch_zone_records_details=oci.dns.models.PatchZoneRecordsDetails(
                    items=items),
                )
            # Getting record_hash for added DNS records
            for vnic in instance.vnics:
                for entry in patch_zone_records_response.data.items:
                    if f'{vnic.hostname}.{domain}' == entry.domain and vnic.ip_addr == entry.rdata:
                        vnic.record_hash = entry.record_hash
            
            
        except Exception as e:
            logging.getLogger().error(f'Unexpected error occured when attempting to add records to DNS zone: {traceback.format_exc()}')
            return response.Response(
                ctx, response_data=json.dumps(
                    {"message": "Could not add records to DNS Zone"}),
                headers={"Content-Type": "application/json"},
                status_code = 501
            )

        # Update instance hostnames
        vcn_client = oci.core.VirtualNetworkClient({}, signer=signer)
        for vnic in instance.vnics:
            if vnic.changed_hostname:
                logging.getLogger().info(f'Attempting to update instance hostname on instance {vnic.instance_id} for vnic {vnic.vnic_id} to {vnic.hostname}')
                vnic_details = oci.core.models.UpdateVnicDetails(hostname_label=vnic.hostname)
                vcn_client.update_vnic(vnic_id=vnic.vnic_id, update_vnic_details=vnic_details)
                
        # Get current instance tags
        instance_client = oci.core.ComputeClient({}, signer=signer)

        # Update instance tags
        logging.getLogger().info(f'Attempting to update instance freeform-tags.')
        instance_client = oci.core.ComputeClient({}, signer=signer)
        logging.getLogger().debug(f'Current instance freeform-tags: {instance.attributes.freeform_tags}')
        new_freeform_tags = instance.attributes.freeform_tags.copy()
        new_freeform_tags.update({
            "hostnames": ",".join([f'{unique_hostname}.{domain}' for unique_hostname in set([ vnic.hostname for vnic in instance.vnics ])]),
            "dns_zone_record_hashes": ",".join([vnic.record_hash for vnic in instance.vnics if vnic.record_hash != ""])
        })
        logging.getLogger().debug(f'New instance freeform-tags: {new_freeform_tags}')
        instance_tags = oci.core.models.UpdateInstanceDetails(freeform_tags=new_freeform_tags)
        instance_client.update_instance(instance_id=instance.instance_id, update_instance_details=instance_tags)       

    return response.Response(
        ctx, response_data=json.dumps(
            {"message": "Successfuly processed the request"}),
        headers={"Content-Type": "application/json"}
    )
