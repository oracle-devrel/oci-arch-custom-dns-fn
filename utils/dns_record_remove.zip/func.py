import io
import json
import logging
import os
import sys
import traceback

from dataclasses import dataclass, field
from typing import Dict

# os.environ["OCI_PYTHON_SDK_NO_SERVICE_IMPORTS"] = "1" #forces import of specific components
import oci
from fdk import response


try:
    DNS_ZONE_OCID = os.environ.get("DNS_ZONE_OCID")
except:
    logging.getLogger().error(f'One of mandatory environment variables is not set.[DNS_ZONE_OCID]')
    sys.exit(1)


# Dataclasses required to store instance attributes during application execution
@dataclass(init=True, repr=True)
class Instance:
    instance_id: str
    request_attributes: dict
    attributes: oci.core.models.instance.Instance = None
    freeform_tags: Dict[str, str] = field(default_factory=dict)


def handler(ctx, data: io.BytesIO = None):

    ## Parse body and extract instance ID
    instances = []
    try:
        body = json.loads(data.getvalue())
        logging.getLogger().debug(f'Body: {body}')

        if isinstance(body, list):
            for entry in body:
                instance_id = entry.get("data", {}).get("resourceId", "")
                if instance_id:
                    instances.append(Instance(instance_id, entry.get("data")))
            logging.getLogger().debug(f"Extracted instance ids from list data: {[entry.instance_id for entry in instances]}")
        
        elif isinstance(body, dict):
            instance_id = body.get("data", {}).get("resourceId", "")
            if instance_id:
                instances.append(Instance(instance_id, body.get("data")))
            logging.getLogger().debug(f"Extracted instance id from dict data: {[entry.instance_id for entry in instances]}")
        
        else:
            logging.getLogger().error(f"Unexpected body received: {body}") 
            return response.Response(
                ctx, 
                response_data=json.dumps(
                    {"message": f"Invalid body {body}"}),
                headers={"Content-Type": "application/json"},
                status_code=400
            )


    except Exception as e:
        logging.getLogger().error(f'error parsing json payload: {traceback.format_exc()}')
        sys.exit(1)


    if not instances:
        logging.getLogger().error(f'No instance_id attribute in received data: {data.getvalue()}')
        return response.Response(
                ctx, 
                response_data=json.dumps(
                    {"message": f"No instance id could be found"}
                ),
                headers={"Content-Type": "application/json"},
                status_code=400
        )
    
    
    ## Getting instance tags
    try:
        signer = oci.auth.signers.get_resource_principals_signer()
        instance_client = oci.core.ComputeClient({}, signer=signer)
        for instance in instances:
            get_instance_response = instance_client.get_instance(instance.instance_id)
            instance.freeform_tags = get_instance_response.data.freeform_tags
             
    except Exception as e:
        logging.getLogger().error(f'Could not get instance freeform tags: {traceback.format_exc()}')
        return response.Response(
            ctx, 
            response_data=json.dumps(
                {"message": "Could not get instance freeform tags. Check logs for more details"}),
            headers={"Content-Type": "application/json"},
            status_code=409
        )

    
    ## Removing entries from DNS Zone
    for instance in instances:
        # Add entries to DNS Zone
        try:
            dns_client = oci.dns.DnsClient({}, signer=signer)
            
            items = []
            if 'dns_zone_record_hashes' not in instance.freeform_tags:
                raise KeyError(f'Could not find dns_zone_record_hashes freeform tags for instance: {instance.instance_id}')
            for record_hash in instance.freeform_tags.get('dns_zone_record_hashes', '').split(','):
                items.append(oci.dns.models.RecordOperation(
                    record_hash=record_hash,
                    operation="REMOVE"
                ))
            
            patch_zone_records_response = dns_client.patch_zone_records(
                zone_name_or_id=DNS_ZONE_OCID,
                patch_zone_records_details=oci.dns.models.PatchZoneRecordsDetails(
                    items=items),
                )
        except Exception as e:
            logging.getLogger().error(f'Unexpected error occured when attempting to remove records from DNS zone: {traceback.format_exc()}')
            return response.Response(
                ctx, response_data=json.dumps(
                    {"message": "Could not remove records from DNS Zone"}),
                headers={"Content-Type": "application/json"},
                status_code = 501
            )

    return response.Response(
        ctx, response_data=json.dumps(
            {"message": "Successfuly processed the request"}),
        headers={"Content-Type": "application/json"}
    )
